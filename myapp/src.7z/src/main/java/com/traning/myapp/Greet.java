package com.traning.myapp;

public class Greet {

	public static String message(String string) {
		System.out.println(string);
		return string;
	}
	

}
