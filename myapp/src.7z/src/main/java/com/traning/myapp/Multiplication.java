package com.traning.myapp;

public class Multiplication {

	public static int mul(int i, int j) {
		// TODO Auto-generated method stub
		System.out.println(i*j);
		return i*j;
	}

}
