package com.traning.myapp.organisation;

public class Employee {

}
