package com.training.myapp.Ecxeption;

public class AgeNotWithinRangeException extends Exception {

	public AgeNotWithinRangeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
