package com.training.myapp.model;

public class PatientManager {
	private Patient waitinglist;
	public void start ()
	{
	System.out.println(" 1 New Patient"   +  " 2 next Patient "  + "3 Waiting list " +  "4  Exit");
	
	
	
	}
}
